# Barbearia NR

Site de controle da barbearia: vendas, estoque, fiado, calculadora e painéis compartilhados.

## Rodar
Precisa do Node 18 ou mais novo. Não tem dependências para instalar.

    npm start

Abra http://localhost:3000. Login padrão: usuário `dadau` (a senha é a que você definiu).

## Colocar no ar
- Use uma hospedagem que rode Node (Render, Railway, Fly.io ou uma VPS). Comando de start: `npm start`.
- **Os dados ficam em `data/data.json`.** Em hospedagem grátis o disco apaga a cada deploy: use um disco/volume persistente e aponte `DATA_FILE` para ele (ex.: `DATA_FILE=/dados/data.json`).
- Use HTTPS (as hospedagens acima já dão). Sem HTTPS as senhas trafegam sem proteção.
- A porta vem da variável `PORT`.
- Faça backup do `data.json` de tempos em tempos.
