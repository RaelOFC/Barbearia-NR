// Barbearia NR — servidor sem dependências (Node 18+). Dados em data/data.json
const http=require("http"),fs=require("fs"),path=require("path"),crypto=require("crypto");
const PORT=process.env.PORT||3000;
const FILE=process.env.DATA_FILE||path.join(__dirname,"data","data.json");
const INDEX=fs.readFileSync(path.join(__dirname,"public","index.html"));
const SEED={name:"Dadau",salt:"nr-dadau-salt-scrypt-1",hash:"eadbe4dbbf9ee170a789d6f6fd8636c155a43e91f9e0e2659f89fd03e95b029cbc6f99a30a51ce442ff8742ace9becddf9cd5f48a473d18d9623df71cb088018"};

let db={accounts:{},panels:{}};
try{db=JSON.parse(fs.readFileSync(FILE,"utf8"))}catch(e){}
function flush(){fs.mkdirSync(path.dirname(FILE),{recursive:true});const t=FILE+".tmp";fs.writeFileSync(t,JSON.stringify(db));fs.renameSync(t,FILE)}
let timer=null;const save=()=>{clearTimeout(timer);timer=setTimeout(flush,200)};
if(!db.accounts.dadau){db.accounts.dadau={...SEED,created:Date.now()};flush()}
process.on("SIGTERM",()=>{flush();process.exit(0)});process.on("SIGINT",()=>{flush();process.exit(0)});

const hp=(p,s)=>crypto.scryptSync(p,s,64);
const sessions=new Map(),fails=new Map();
const newToken=u=>{const t=crypto.randomBytes(24).toString("hex");sessions.set(t,{u,exp:Date.now()+12*36e5});return t};
const send=(res,c,o)=>{res.writeHead(c,{"Content-Type":"application/json","Cache-Control":"no-store"});res.end(JSON.stringify(o))};
const readBody=req=>new Promise((ok,no)=>{let d="";req.on("data",c=>{d+=c;if(d.length>1e5){no(new Error("grande"));req.destroy()}});req.on("end",()=>{try{ok(d?JSON.parse(d):{})}catch(e){no(e)}})});
const validU=u=>typeof u==="string"&&/^[a-z0-9_.-]{3,30}$/.test(u);
const KINDS=["sale","stock","fiado"];
function clean(o){const r={};for(const k of["type","desc","who","name"])if(typeof o[k]==="string")r[k]=o[k].slice(0,120);
  for(const k of["qty","value","price","at","paidAt"])if(Number.isFinite(o[k]))r[k]=o[k];
  if(typeof o.paid==="boolean")r.paid=o.paid;return r}

async function api(req,res,p){
  const m=req.method,b=["POST","PATCH"].includes(m)?await readBody(req):{};
  if(m==="POST"&&(p==="/login"||p==="/register")){
    const u=String(b.username||"").trim().toLowerCase(),pw=String(b.password||"");
    const key=req.socket.remoteAddress+"|"+u,f=fails.get(key)||{n:0,t:Date.now()};
    if(Date.now()-f.t>6e5){f.n=0;f.t=Date.now()}
    if(f.n>=10)return send(res,429,{error:"Muitas tentativas. Espere alguns minutos."});
    if(!validU(u))return send(res,400,{error:"Usuário: 3 a 30 caracteres (letras, números, _ . -)."});
    if(p==="/register"){
      if(pw.length<8||pw.length>200)return send(res,400,{error:"A senha precisa ter ao menos 8 caracteres."});
      if(db.accounts[u])return send(res,409,{error:"Esse usuário já existe."});
      const name=String(b.name||u).trim().slice(0,60)||u,salt=crypto.randomUUID();
      db.accounts[u]={name,salt,hash:hp(pw,salt).toString("hex"),created:Date.now()};save();
      return send(res,200,{token:newToken(u),name});
    }
    const a=db.accounts[u];
    if(!a||!crypto.timingSafeEqual(hp(pw,a.salt),Buffer.from(a.hash,"hex"))){f.n++;fails.set(key,f);return send(res,401,{error:"Usuário ou senha incorretos."})}
    fails.delete(key);return send(res,200,{token:newToken(u),name:a.name});
  }
  const s=sessions.get((req.headers.authorization||"").replace("Bearer ",""));
  if(!s||s.exp<Date.now())return send(res,401,{error:"Sessão expirada. Entre de novo."});
  const u=s.u;let x;
  if(p==="/panels"){
    if(m==="GET")return send(res,200,{panels:Object.entries(db.panels).filter(([,v])=>v.members.includes(u)).map(([id,v])=>({id,name:v.name,owner:v.owner,members:v.members,created:v.created}))});
    if(m==="POST"){
      if(Object.values(db.panels).filter(v=>v.owner===u).length>=20)return send(res,400,{error:"Limite de painéis atingido."});
      const id=crypto.randomUUID();db.panels[id]={name:String(b.name||"Painel").slice(0,60),owner:u,members:[u],created:Date.now(),items:{}};save();return send(res,200,{id});
    }
  }
  if(x=p.match(/^\/panels\/([\w-]+)(\/.*)?$/)){
    const pn=db.panels[x[1]];if(!pn||!pn.members.includes(u))return send(res,404,{error:"Painel não encontrado."});
    const r=x[2]||"";let y;
    if(r==="/items"&&m==="GET")return send(res,200,{items:Object.entries(pn.items).map(([id,v])=>({id,...v}))});
    if(r==="/items"&&m==="POST"){
      const it=clean(b);if(!KINDS.includes(it.type))return send(res,400,{error:"Tipo inválido."});
      if(Object.keys(pn.items).length>=5000)return send(res,400,{error:"Limite de itens atingido."});
      it.by=u;it.at=it.at||Date.now();const id=crypto.randomUUID();pn.items[id]=it;save();return send(res,200,{id});
    }
    if(y=r.match(/^\/items\/([\w-]+)$/)){
      if(!pn.items[y[1]])return send(res,404,{error:"Item não encontrado."});
      if(m==="PATCH"){const c=clean(b);delete c.type;pn.items[y[1]]={...pn.items[y[1]],...c};save();return send(res,200,{ok:1})}
      if(m==="DELETE"){delete pn.items[y[1]];save();return send(res,200,{ok:1})}
    }
    if(r==="/members"&&m==="POST"){
      const t=String(b.username||"").trim().toLowerCase();
      if(!db.accounts[t])return send(res,404,{error:"Usuário não encontrado."});
      if(pn.members.includes(t))return send(res,409,{error:"Essa pessoa já está no painel."});
      pn.members.push(t);save();return send(res,200,{ok:1});
    }
    if(y=r.match(/^\/members\/([^/]+)$/)){
      const t=decodeURIComponent(y[1]);
      if(m==="DELETE"){if(pn.owner!==u||t===pn.owner)return send(res,403,{error:"Só o dono remove membros."});pn.members=pn.members.filter(v=>v!==t);save();return send(res,200,{ok:1})}
    }
  }
  send(res,404,{error:"Rota inexistente."});
}
http.createServer(async(req,res)=>{
  try{
    const p=new URL(req.url,"http://x").pathname;
    if(p.startsWith("/api/"))return await api(req,res,p.slice(4));
    if(req.method==="GET"&&(p==="/"||p==="/index.html")){res.writeHead(200,{"Content-Type":"text/html; charset=utf-8","X-Content-Type-Options":"nosniff","Referrer-Policy":"no-referrer"});return res.end(INDEX)}
    res.writeHead(404);res.end("Não encontrado");
  }catch(e){if(!res.headersSent)send(res,500,{error:"Erro no servidor."})}
}).listen(PORT,()=>console.log("Barbearia NR rodando na porta "+PORT));
